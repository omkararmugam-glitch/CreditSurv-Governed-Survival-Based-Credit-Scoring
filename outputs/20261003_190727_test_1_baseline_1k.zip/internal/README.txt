INTERNAL -- NEVER SEND ANY FILE IN THIS FOLDER TO AN APPLICANT.

internal_review_flags.csv: one row per explained rejected applicant -- fair-lending flag,
non-disclosable drivers, the feature and attribution behind each stated reason.
internal_review_records.jsonl: the full internal review record per applicant, as JSON.

Applicant notices are in ../adverse_action_notices.zip and contain none of this.
